<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

namespace local_skillupsintegration\connector;

use local_skillupsintegration\problem;

/**
 * An integration accepting authenticated REST or webhook records.
 *
 * @package    local_skillupsintegration
 * @copyright  2026 SkillUps Academy
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
final class inbound extends base {
    /**
     * Declare the supported integration commands.
     *
     * {@inheritdoc}
     */
    public function capabilities(): array {
        return ['user', 'course', 'push'];
    }

    /**
     * Identify the configured authentication model.
     *
     * {@inheritdoc}
     */
    public function authentication(): string {
        return 'auth_inbound';
    }

    /**
     * Fetch a validated page of provider records.
     *
     * {@inheritdoc}
     */
    public function page(string $entity, string $cursor): array {
        throw new problem('unavailable');
    }
}
