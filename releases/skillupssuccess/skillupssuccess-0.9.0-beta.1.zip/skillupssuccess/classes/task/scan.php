<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

namespace local_skillupssuccess\task;

use local_skillupssuccess\store;
use local_skillupssuccess\util;

/**
 * Collect the next cohorts of opt-in courses.
 *
 * @package    local_skillupssuccess
 * @copyright  2026 SkillUps Academy
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
final class scan extends \core\task\scheduled_task {
    /**
     * Name shown in Moodle scheduling.
     */
    public function get_name(): string {
        return util::str('taskscan');
    }

    /**
     * Visit a bounded number of course batches per invocation.
     */
    public function execute(): void {
        global $DB;
        $courses = $DB->get_records_select(
            store::POLICY,
            'enabled = 1 AND nextscan <= :now',
            ['now' => time()],
            'nextscan ASC, id ASC',
            'id,courseid',
            0,
            4
        );
        foreach ($courses as $row) {
            store::scan($row->courseid);
        }
    }
}
